/*
 * Copyright (c) 2025, Your Name
 *
 * Multi-Sensor Data Acquisition System for STM32F407VET6
 * Supports LD2402, ZP16, MH-Z14, ZH03B sensors
 */

#include <rtthread.h>
#include <rtdevice.h>
#include <board.h>

/* 传感器设备定义 */
#define CONSOLE_UART_NAME    "uart1"   // 控制台串口
#define LD2402_UART_NAME     "uart4"   // PA0(TX), PA1(RX)
#define ZP16_UART_NAME       "uart6"   // PC6(TX), PC7(RX)
#define MHZ14_UART_NAME      "uart5"   // PC12(TX), PD2(RX)
#define ZH03B_UART_NAME      "uart2"   // PD5(TX), PD6(RX)

/* 波特率设置 */
#define CONSOLE_BAUD_RATE    115200
#define LD2402_BAUD_RATE     115200
#define ZP16_BAUD_RATE       9600
#define MHZ14_BAUD_RATE      9600
#define ZH03B_BAUD_RATE      9600

/* 传感器数据结构 */
struct sensor_data {
    float pm25;          // PM2.5浓度(ug/m3)
    float tvoc;          // TVOC浓度(mg/m3)
    float co2;           // CO2浓度(ppm)
    float distance;      // 距离(m)
    uint8_t motion;      // 运动状态(0/1)
    uint8_t valid;       // 数据有效标志
    uint8_t sensor_status[4]; // 各传感器状态(0=OK, 1=Error)
};

static struct sensor_data sensor_data;
static rt_device_t console_dev = RT_NULL;
static rt_device_t ld2402_dev = RT_NULL;
static rt_device_t zp16_dev = RT_NULL;
static rt_device_t mhz14_dev = RT_NULL;
static rt_device_t zh03b_dev = RT_NULL;

/* UART配置函数 */
static void uart_config(rt_device_t dev, rt_uint32_t baud) {
    struct serial_configure config = RT_SERIAL_CONFIG_DEFAULT;
    config.baud_rate = baud;
    config.data_bits = DATA_BITS_8;
    config.stop_bits = STOP_BITS_1;
    config.parity = PARITY_NONE;
    config.bit_order = BIT_ORDER_LSB;
    config.invert = NRZ_NORMAL;
    config.bufsz = 512;
    rt_device_control(dev, RT_DEVICE_CTRL_CONFIG, &config);
}

/* 清空串口缓冲区 */
static void uart_flush(rt_device_t dev) {
    uint8_t dummy;
    while (rt_device_read(dev, 0, &dummy, 1) > 0);
}

/* 打印十六进制数据 */
static void print_hex(const char* label, const uint8_t* data, rt_size_t len) {
    rt_kprintf("%s [%d]: ", label, len);
    for (rt_size_t i = 0; i < len; i++) {
        rt_kprintf("%02X ", data[i]);
    }
    rt_kprintf("\n");
}

/* 计算校验和 */
static uint8_t calculate_checksum(uint8_t *data, uint8_t len) {
    uint8_t checksum = 0;
    for (uint8_t i = 1; i < len - 1; i++) {
        checksum += data[i];
    }
    return (~checksum) + 1;
}

/* LD2402人体存在传感器读取 */
static rt_err_t ld2402_read_data(float *distance, uint8_t *motion) {
    uint8_t cmd[] = {0xFD, 0xFC, 0xFB, 0xFA, 0x02, 0x00, 0x86, 0x00, 0x04, 0x03, 0x02, 0x01};
    uint8_t response[14] = {0};
    rt_size_t len;

    uart_flush(ld2402_dev);

    // 发送命令
    if (rt_device_write(ld2402_dev, 0, cmd, sizeof(cmd)) != sizeof(cmd)) {
        rt_kprintf("LD2402 write failed\n");
        return -RT_ERROR;
    }

    // 等待响应
    rt_thread_mdelay(300);
    len = rt_device_read(ld2402_dev, 0, response, sizeof(response));

    if (len < 14) {
        print_hex("LD2402 short response", response, len);
        return -RT_ERROR;
    }

    // 验证帧头
    if (response[0] != 0xFD || response[1] != 0xFC ||
        response[2] != 0xFB || response[3] != 0xFA) {
        rt_kprintf("LD2402 invalid header\n");
        return -RT_ERROR;
    }

    *distance = (float)((response[8] << 8) | response[9]) / 100.0f;
    *motion = (response[6] != 0);
    return RT_EOK;
}

/* ZP16 TVOC传感器读取 */
static rt_err_t zp16_read_data(float *tvoc) {
    uint8_t cmd[] = {0xFF, 0x01, 0x86, 0x00, 0x00, 0x00, 0x00, 0x00, 0x79};
    uint8_t response[9] = {0};
    rt_size_t len;

    uart_flush(zp16_dev);

    // 发送命令
    if (rt_device_write(zp16_dev, 0, cmd, sizeof(cmd)) != sizeof(cmd)) {
        rt_kprintf("ZP16 write failed\n");
        return -RT_ERROR;
    }

    // 等待响应
    rt_thread_mdelay(300);
    len = rt_device_read(zp16_dev, 0, response, sizeof(response));

    if (len != sizeof(response)) {
        print_hex("ZP16 incomplete response", response, len);
        return -RT_ERROR;
    }

    // 校验和验证
    if (response[8] != calculate_checksum(response, sizeof(response))) {
        rt_kprintf("ZP16 checksum error\n");
        return -RT_ERROR;
    }

    *tvoc = (float)((response[2] << 8) | response[3]) / 100.0f;
    return RT_EOK;
}

/* MH-Z14 CO2传感器读取 */
static rt_err_t mhz14_read_data(float *co2) {
    uint8_t cmd[] = {0xFF, 0x01, 0x86, 0x00, 0x00, 0x00, 0x00, 0x00, 0x79};
    uint8_t response[9] = {0};
    rt_size_t len;

    uart_flush(mhz14_dev);

    // 发送命令
    if (rt_device_write(mhz14_dev, 0, cmd, sizeof(cmd)) != sizeof(cmd)) {
        rt_kprintf("MH-Z14 write failed\n");
        return -RT_ERROR;
    }

    // 等待响应
    rt_thread_mdelay(300);
    len = rt_device_read(mhz14_dev, 0, response, sizeof(response));

    if (len != sizeof(response)) {
        print_hex("MH-Z14 incomplete response", response, len);
        return -RT_ERROR;
    }

    // 校验和验证
    if (response[8] != calculate_checksum(response, sizeof(response))) {
        rt_kprintf("MH-Z14 checksum error\n");
        return -RT_ERROR;
    }

    *co2 = (float)((response[2] << 8) | response[3]);
    return RT_EOK;
}

/* ZH03B PM2.5传感器读取 */
static rt_err_t zh03b_read_data(float *pm25) {
    uint8_t cmd[] = {0xFF, 0x01, 0x86, 0x00, 0x00, 0x00, 0x00, 0x00, 0x79};
    uint8_t response[24] = {0};
    rt_size_t len;
    uint16_t checksum = 0;

    uart_flush(zh03b_dev);

    // 发送命令
    if (rt_device_write(zh03b_dev, 0, cmd, sizeof(cmd)) != sizeof(cmd)) {
        rt_kprintf("ZH03B write failed\n");
        return -RT_ERROR;
    }

    // 等待响应
    rt_thread_mdelay(300);
    len = rt_device_read(zh03b_dev, 0, response, sizeof(response));

    if (len < 24) {
        print_hex("ZH03B incomplete response", response, len);
        return -RT_ERROR;
    }

    // 验证帧头
    if (response[0] != 0x42 || response[1] != 0x4D) {
        rt_kprintf("ZH03B invalid header\n");
        return -RT_ERROR;
    }

    // 计算校验和
    for (int i = 0; i < 22; i++) {
        checksum += response[i];
    }

    uint16_t recv_checksum = (response[22] << 8) | response[23];
    if (checksum != recv_checksum) {
        rt_kprintf("ZH03B checksum error: calc=0x%04X, recv=0x%04X\n", checksum, recv_checksum);
        return -RT_ERROR;
    }

    *pm25 = (float)((response[12] << 8) | response[13]);
    return RT_EOK;
}

/* 传感器初始化 */
static void sensor_init(void) {
    // 初始化控制台串口
    console_dev = rt_device_find(CONSOLE_UART_NAME);
    if (console_dev && rt_device_open(console_dev, RT_DEVICE_FLAG_RDWR) == RT_EOK) {
        uart_config(console_dev, CONSOLE_BAUD_RATE);
        rt_kprintf("Console initialized at %s, %d baud\n", CONSOLE_UART_NAME, CONSOLE_BAUD_RATE);
    }

    // 初始化LD2402
    ld2402_dev = rt_device_find(LD2402_UART_NAME);
    if (ld2402_dev && rt_device_open(ld2402_dev, RT_DEVICE_FLAG_RDWR) == RT_EOK) {
        uart_config(ld2402_dev, LD2402_BAUD_RATE);
        rt_kprintf("LD2402 initialized at %s, %d baud\n", LD2402_UART_NAME, LD2402_BAUD_RATE);
    }

    // 初始化ZP16
    zp16_dev = rt_device_find(ZP16_UART_NAME);
    if (zp16_dev && rt_device_open(zp16_dev, RT_DEVICE_FLAG_RDWR) == RT_EOK) {
        uart_config(zp16_dev, ZP16_BAUD_RATE);
        rt_kprintf("ZP16 initialized at %s, %d baud\n", ZP16_UART_NAME, ZP16_BAUD_RATE);
    }

    // 初始化MH-Z14
    mhz14_dev = rt_device_find(MHZ14_UART_NAME);
    if (mhz14_dev && rt_device_open(mhz14_dev, RT_DEVICE_FLAG_RDWR) == RT_EOK) {
        uart_config(mhz14_dev, MHZ14_BAUD_RATE);
        rt_kprintf("MH-Z14 initialized at %s, %d baud\n", MHZ14_UART_NAME, MHZ14_BAUD_RATE);
    }

    // 初始化ZH03B
    zh03b_dev = rt_device_find(ZH03B_UART_NAME);
    if (zh03b_dev && rt_device_open(zh03b_dev, RT_DEVICE_FLAG_RDWR) == RT_EOK) {
        uart_config(zh03b_dev, ZH03B_BAUD_RATE);
        rt_kprintf("ZH03B initialized at %s, %d baud\n", ZH03B_UART_NAME, ZH03B_BAUD_RATE);
    }
}

/* 传感器数据读取线程 */
static void sensor_thread_entry(void *parameter) {
    rt_kprintf("\nSensor monitoring started...\n");
    rt_thread_mdelay(5000); // 延长预热时间

    while (1) {
        rt_memset(&sensor_data, 0, sizeof(sensor_data));
        sensor_data.valid = 1;

        rt_kprintf("\n===== Reading Sensors =====\n");

        // 读取LD2402 (3次重试)
        if (ld2402_dev) {
            int retry = 3;
            while (retry-- > 0) {
                if (ld2402_read_data(&sensor_data.distance, &sensor_data.motion) == RT_EOK) {
                    sensor_data.sensor_status[0] = 0;
                    break;
                }
                rt_thread_mdelay(100);
            }
            if (retry <= 0) {
                sensor_data.valid = 0;
                sensor_data.sensor_status[0] = 1;
                rt_kprintf("LD2402 read failed after 3 retries\n");
            }
        }

        // 读取ZP16
        if (zp16_dev) {
            if (zp16_read_data(&sensor_data.tvoc) != RT_EOK) {
                sensor_data.valid = 0;
                sensor_data.sensor_status[1] = 1;
                rt_kprintf("ZP16 read failed, checking connection...\n");
                uart_flush(zp16_dev);
                uart_config(zp16_dev, ZP16_BAUD_RATE);
            } else {
                sensor_data.sensor_status[1] = 0;
            }
        }

        // 读取MH-Z14 (尝试不同波特率)
        if (mhz14_dev) {
            if (mhz14_read_data(&sensor_data.co2) != RT_EOK) {
                uart_config(mhz14_dev, 19200);
                if (mhz14_read_data(&sensor_data.co2) != RT_EOK) {
                    sensor_data.valid = 0;
                    sensor_data.sensor_status[2] = 1;
                    rt_kprintf("MH-Z14 read failed at both 9600 and 19200 baud\n");
                } else {
                    sensor_data.sensor_status[2] = 0;
                }
            } else {
                sensor_data.sensor_status[2] = 0;
            }
        }

        // 读取ZH03B
        if (zh03b_dev) {
            // 先切换为问答模式
            uint8_t mode_cmd[] = {0xFF, 0x01, 0x78, 0x41, 0x00, 0x00, 0x00, 0x00, 0x46};
            rt_device_write(zh03b_dev, 0, mode_cmd, sizeof(mode_cmd));
            rt_thread_mdelay(200);

            if (zh03b_read_data(&sensor_data.pm25) != RT_EOK) {
                sensor_data.valid = 0;
                sensor_data.sensor_status[3] = 1;
                rt_kprintf("ZH03B read failed, check power and connections\n");
            } else {
                sensor_data.sensor_status[3] = 0;
            }
        }

        // 打印结果
        rt_kprintf("\n===== Sensor Data =====\n");
        if (sensor_data.valid) {
            rt_kprintf("Distance: %.2f m\n", sensor_data.distance);
            rt_kprintf("Motion: %s\n", sensor_data.motion ? "Detected" : "None");
            rt_kprintf("TVOC: %.2f mg/m3\n", sensor_data.tvoc);
            rt_kprintf("CO2: %.0f ppm\n", sensor_data.co2);
            rt_kprintf("PM2.5: %.1f ug/m3\n", sensor_data.pm25);
        } else {
            rt_kprintf("Sensor data incomplete!\n");
            if (sensor_data.sensor_status[0]) rt_kprintf("- LD2402 error\n");
            if (sensor_data.sensor_status[1]) rt_kprintf("- ZP16 error\n");
            if (sensor_data.sensor_status[2]) rt_kprintf("- MH-Z14 error\n");
            if (sensor_data.sensor_status[3]) rt_kprintf("- ZH03B error\n");
        }
        rt_kprintf("======================\n");

        rt_thread_mdelay(3000); // 3秒采样间隔
    }
}

int main(void) {
    rt_kprintf("\n===== Sensor System Boot =====\n");

    // 硬件初始化
    sensor_init();

    // 创建传感器线程
    rt_thread_t tid = rt_thread_create("sensor",
                                     sensor_thread_entry,
                                     RT_NULL,
                                     4096,  // 增大栈空间
                                     15,
                                     10);
    if (tid != RT_NULL) {
        rt_thread_startup(tid);
    } else {
        rt_kprintf("Failed to create sensor thread!\n");
    }

    return 0;
}
